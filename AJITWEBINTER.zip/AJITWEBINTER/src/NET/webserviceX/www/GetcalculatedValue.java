package NET.webserviceX.www;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class GetcalculatedValue
 */
public class GetcalculatedValue extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetcalculatedValue() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{   PrintWriter out=response.getWriter();
	    String webmethod=request.getParameter("webmethod");
	    if(webmethod.equalsIgnoreCase("APR") || webmethod.equalsIgnoreCase("LEASE")) 
	    {
	    double Loanamt=Double.parseDouble(request.getParameter("Loanamt"));
		//double lamt=Double.parseDouble(Loanamt);
		double ExtraCost=Double.parseDouble(request.getParameter("ExtraCost"));
		System.out.println("int--"+request.getParameter("Loanamt"));
		System.out.println("int--"+request.getParameter("ExtraCost"));
		double InterstRate=Double.parseDouble(request.getParameter("InterstRate"));
		double Months=Double.parseDouble(request.getParameter("Months"));
		System.out.println("APR--"+webmethod);
		double res=MainMethod.lonavlue(Loanamt,ExtraCost,InterstRate,Months,webmethod);
		out.print(res);
	    }
	    if(webmethod.equalsIgnoreCase("LOANMONTH") || webmethod.equalsIgnoreCase("LOANNUMBER")) 
	    {
	    	 double Loanamt=Double.parseDouble(request.getParameter("Loanamt"));
	    	 double InterstRate=Double.parseDouble(request.getParameter("InterstRate"));
	 		 double Months=Double.parseDouble(request.getParameter("Months"));
	 		 System.out.println("APR--"+webmethod);
	 		 System.out.println("--"+Loanamt+"|"+InterstRate+"|"+Months);
	 		double res=MainMethod.loanmonth(Loanamt,InterstRate,Months,webmethod);
	 		out.print(res);
	    }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
