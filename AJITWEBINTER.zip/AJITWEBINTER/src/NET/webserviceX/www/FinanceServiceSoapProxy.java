package NET.webserviceX.www;

public class FinanceServiceSoapProxy implements NET.webserviceX.www.FinanceServiceSoap {
  private String _endpoint = null;
  private NET.webserviceX.www.FinanceServiceSoap financeServiceSoap = null;
  
  public FinanceServiceSoapProxy() {
    _initFinanceServiceSoapProxy();
  }
  
  public FinanceServiceSoapProxy(String endpoint) {
    _endpoint = endpoint;
    _initFinanceServiceSoapProxy();
  }
  
  private void _initFinanceServiceSoapProxy() {
    try {
      financeServiceSoap = (new NET.webserviceX.www.FinanceServiceLocator()).getFinanceServiceSoap();
      if (financeServiceSoap != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)financeServiceSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)financeServiceSoap)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (financeServiceSoap != null)
      ((javax.xml.rpc.Stub)financeServiceSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public NET.webserviceX.www.FinanceServiceSoap getFinanceServiceSoap() {
    if (financeServiceSoap == null)
      _initFinanceServiceSoapProxy();
    return financeServiceSoap;
  }
  
  public double loanMonthlyPayment(double loanAmount, double interestRate, double months) throws java.rmi.RemoteException{
    if (financeServiceSoap == null)
      _initFinanceServiceSoapProxy();
    return financeServiceSoap.loanMonthlyPayment(loanAmount, interestRate, months);
  }
  
  public double loanNumberOfPayment(double loanAmount, double interestRate, double monthlyPayment) throws java.rmi.RemoteException{
    if (financeServiceSoap == null)
      _initFinanceServiceSoapProxy();
    return financeServiceSoap.loanNumberOfPayment(loanAmount, interestRate, monthlyPayment);
  }
  
  public double leaseMonthlyPayment(double loanAmount, double residualValue, double interestRate, double months) throws java.rmi.RemoteException{
    if (financeServiceSoap == null)
      _initFinanceServiceSoapProxy();
    return financeServiceSoap.leaseMonthlyPayment(loanAmount, residualValue, interestRate, months);
  }
  
  public double APR(double loanAmount, double extraCost, double interestRate, double months) throws java.rmi.RemoteException{
    if (financeServiceSoap == null)
      _initFinanceServiceSoapProxy();
    return financeServiceSoap.APR(loanAmount, extraCost, interestRate, months);
  }
  
  
}