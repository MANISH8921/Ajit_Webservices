/**
 * FinanceServiceSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package NET.webserviceX.www;

public interface FinanceServiceSoap extends java.rmi.Remote {
    public double loanMonthlyPayment(double loanAmount, double interestRate, double months) throws java.rmi.RemoteException;
    public double loanNumberOfPayment(double loanAmount, double interestRate, double monthlyPayment) throws java.rmi.RemoteException;
    public double leaseMonthlyPayment(double loanAmount, double residualValue, double interestRate, double months) throws java.rmi.RemoteException;
    public double APR(double loanAmount, double extraCost, double interestRate, double months) throws java.rmi.RemoteException;
}
