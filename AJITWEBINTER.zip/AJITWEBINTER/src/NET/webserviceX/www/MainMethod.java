package NET.webserviceX.www;

import java.rmi.RemoteException;

public class MainMethod {

	/**
	 * @param args
	 * */
	  
	 static{
		   // System.getProperties().put("http.proxyHost", "10.144.17.172");
	       // System.getProperties().put("http.proxyPort", "3128");
	       // System.getProperties().put("http.proxySet", "true");
		 }
	 
	public static double lonavlue(double lamt,double extr,double intrate,double month,String webmethod)
	{   double s=0.0;
		try
		{
			FinanceServiceSoapProxy prx=new FinanceServiceSoapProxy();
			if(webmethod.equalsIgnoreCase("APR"))
			s=prx.APR(lamt, extr, intrate, month);
			if(webmethod.equalsIgnoreCase("LEASE")) 
			 s=prx.leaseMonthlyPayment(lamt, extr, intrate, month);
			System.out.println("---res--"+s);
		}
		catch (RemoteException e) 
		{
			
		}
		return s;
	}
	public static double loanmonth(double lmat,double intrate,double months,String webmethod)
	{  double val=0.0;
		try
		{
			FinanceServiceSoapProxy prx=new FinanceServiceSoapProxy();
			if(webmethod.equalsIgnoreCase("LOANMONTH"))
			val=prx.loanMonthlyPayment(lmat, intrate, months);
			if(webmethod.equalsIgnoreCase("LOANNUMBER"))
			val=prx.loanNumberOfPayment(lmat, intrate, months);
		}
		catch (RemoteException e) 
		{
			
		}
		return val;
	}
	
	public static void main(String args[])
	{
	  MainMethod m2= new MainMethod();
	  try
	  {
	  FinanceServiceSoapProxy prx=new FinanceServiceSoapProxy();
	  double d=	prx.APR(8898979, 7, 8, 10);
	  //=prx.APR(45455.0, 100, 4, 10, "bhu");
	  System.out.println("---------"+d);
	  }
	  catch (RemoteException e) 
		{
			
		}
		
	
	}
	
}
